# chemmodlab
Converting ChemModLab, a web server for building cheminformatics machine learning models, into an R package.
