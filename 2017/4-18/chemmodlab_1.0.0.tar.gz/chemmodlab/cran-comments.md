## Test environments
* local Windows 10 install, R 3.3.1
* local Ubuntu 14.04 install, R 3.3.3
* win-builder (devel and release) 

## R CMD check results
There were no ERRORs or WARNINGs

There was 1 NOTE:

* checking CRAN incoming feasibility ... NOTE
Maintainer: 'Jeremy Ash <jrash@ncsu.edu>'

New submission

Possibly mis-spelled words in DESCRIPTION:
  Cheminformatics (3:10, 15:37)
  QSARs (18:52)

This is the first submission of the package.  Those words aren't mis-spelled.  
  
## Downstream dependencies
There are currently no downstream dependencies for this package.
